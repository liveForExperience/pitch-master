-- MySQL dump 10.13  Distrib 8.0.33, for Linux (x86_64)
--
-- Host: 127.0.0.1    Database: pitch_master
-- ------------------------------------------------------
-- Server version	8.0.33

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `club`
--

DROP TABLE IF EXISTS `club`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `club` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `tournament_id` bigint NOT NULL COMMENT '所属赛事ID',
  `name` varchar(64) COLLATE utf8mb4_general_ci NOT NULL COMMENT '俱乐部名称',
  `description` varchar(255) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `created_by` bigint DEFAULT NULL,
  `updated_by` bigint DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `fk_club_tournament` (`tournament_id`),
  CONSTRAINT `fk_club_tournament` FOREIGN KEY (`tournament_id`) REFERENCES `tournament` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci COMMENT='俱乐部';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `club`
--

LOCK TABLES `club` WRITE;
/*!40000 ALTER TABLE `club` DISABLE KEYS */;
/*!40000 ALTER TABLE `club` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `flyway_schema_history`
--

DROP TABLE IF EXISTS `flyway_schema_history`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `flyway_schema_history` (
  `installed_rank` int NOT NULL,
  `version` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `description` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL,
  `type` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `script` varchar(1000) COLLATE utf8mb4_unicode_ci NOT NULL,
  `checksum` int DEFAULT NULL,
  `installed_by` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `installed_on` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `execution_time` int NOT NULL,
  `success` tinyint(1) NOT NULL,
  PRIMARY KEY (`installed_rank`),
  KEY `flyway_schema_history_s_idx` (`success`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `flyway_schema_history`
--

LOCK TABLES `flyway_schema_history` WRITE;
/*!40000 ALTER TABLE `flyway_schema_history` DISABLE KEYS */;
INSERT INTO `flyway_schema_history` VALUES (1,'1','initial auth system','SQL','V1__initial_auth_system.sql',1633125725,'root','2026-03-29 14:57:03',298,1),(2,'2','core domain schema','SQL','V2__core_domain_schema.sql',1353463461,'root','2026-03-29 14:57:04',965,1),(3,'3','match operation and stats','SQL','V3__match_operation_and_stats.sql',-1778149176,'root','2026-03-29 14:57:04',304,1),(4,'4','initial admin data','SQL','V4__initial_admin_data.sql',-460631079,'root','2026-03-29 14:57:04',91,1),(5,'5','rating model unification','SQL','V5__rating_model_unification.sql',986517593,'root','2026-03-29 14:57:05',256,1),(6,'6','add match end time','SQL','V6__add_match_end_time.sql',-458853671,'root','2026-03-29 14:57:05',80,1),(7,'7','add groups published','SQL','V7__add_groups_published.sql',-1617833448,'root','2026-03-29 14:57:05',84,1),(8,'8','add team names','SQL','V8__add_team_names.sql',1310716574,'root','2026-03-29 14:57:05',69,1),(9,'9','add game format','SQL','V9__add_game_format.sql',-1410935011,'root','2026-03-29 14:57:05',85,1),(10,'10','add game index and duration','SQL','V10__add_game_index_and_duration.sql',-46114669,'root','2026-03-29 14:57:06',61,1),(11,'11','add match soft delete and actual start time','SQL','V11__add_match_soft_delete_and_actual_start_time.sql',895616175,'root','2026-03-29 14:57:06',465,1),(12,'12','add settlement fields','SQL','V12__add_settlement_fields.sql',-2046620783,'root','2026-03-29 14:57:06',113,1),(13,'13','remove settled status','SQL','V13__remove_settled_status.sql',1380976475,'root','2026-03-29 14:57:06',17,1),(14,'14','platform concept and player split','SQL','V14__platform_concept_and_player_split.sql',1813818735,'root','2026-03-29 14:57:07',545,1),(15,'15','remove grouping draft status','SQL','V15__remove_grouping_draft_status.sql',1742467649,'root','2026-03-29 14:57:07',29,1),(16,'16','decouple player tournament fk','SQL','V16__decouple_player_tournament_fk.sql',-19168964,'root','2026-03-30 02:16:42',232,1),(17,'17','fix player stat duplicates','SQL','V17__fix_player_stat_duplicates.sql',-1661894111,'root','2026-03-30 05:54:03',86,1),(18,'18','cleanup deprecated fields','SQL','V18__cleanup_deprecated_fields.sql',1052401686,'root','2026-03-30 12:16:14',412,1),(19,'19','tournament soft delete','SQL','V19__tournament_soft_delete.sql',951842761,'root','2026-03-30 14:52:29',419,1);
/*!40000 ALTER TABLE `flyway_schema_history` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `game_participant`
--

DROP TABLE IF EXISTS `game_participant`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `game_participant` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `game_id` bigint NOT NULL,
  `player_id` bigint NOT NULL,
  `goals` int DEFAULT '0',
  `assists` int DEFAULT '0',
  `is_mvp` tinyint DEFAULT '0',
  `rating` decimal(3,1) DEFAULT '6.0',
  `created_by` bigint DEFAULT NULL,
  `updated_by` bigint DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `fk_part_game` (`game_id`),
  KEY `fk_part_player` (`player_id`),
  CONSTRAINT `fk_part_game` FOREIGN KEY (`game_id`) REFERENCES `match_game` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_part_player` FOREIGN KEY (`player_id`) REFERENCES `player` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=33 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci COMMENT='单场比赛球员数据';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `game_participant`
--

LOCK TABLES `game_participant` WRITE;
/*!40000 ALTER TABLE `game_participant` DISABLE KEYS */;
INSERT INTO `game_participant` VALUES (23,17,2,0,0,0,6.0,1,1,'2026-04-04 19:31:32','2026-04-04 19:31:32'),(24,17,7,0,0,0,6.0,1,1,'2026-04-04 19:31:32','2026-04-04 19:31:32'),(25,17,8,0,0,0,6.0,1,1,'2026-04-04 19:31:32','2026-04-04 19:31:32'),(26,17,13,0,0,0,6.0,1,1,'2026-04-04 19:31:32','2026-04-04 19:31:32'),(27,17,14,0,0,0,6.0,1,1,'2026-04-04 19:31:32','2026-04-04 19:31:32'),(28,17,17,0,0,0,6.0,1,1,'2026-04-04 19:31:32','2026-04-04 19:31:32'),(29,17,18,0,0,0,6.0,1,1,'2026-04-04 19:31:32','2026-04-04 19:31:32'),(30,17,19,0,0,0,6.0,1,1,'2026-04-04 19:31:32','2026-04-04 19:31:32'),(31,17,20,0,0,0,6.0,1,1,'2026-04-04 19:31:32','2026-04-04 19:31:32'),(32,17,21,0,0,0,6.0,1,1,'2026-04-04 19:31:32','2026-04-04 19:31:32');
/*!40000 ALTER TABLE `game_participant` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `match`
--

DROP TABLE IF EXISTS `match`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `match` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `tournament_id` bigint NOT NULL COMMENT '所属赛事ID',
  `title` varchar(128) COLLATE utf8mb4_general_ci NOT NULL COMMENT '赛事标题',
  `start_time` datetime NOT NULL COMMENT '开始时间',
  `actual_start_time` datetime DEFAULT NULL COMMENT '实际开赛时间（管理员触发时设置）',
  `end_time` datetime DEFAULT NULL COMMENT '比赛结束时间',
  `registration_deadline` datetime NOT NULL COMMENT '报名截止时间',
  `cancel_deadline` datetime DEFAULT NULL COMMENT '取消报名截止时间',
  `location` varchar(255) COLLATE utf8mb4_general_ci DEFAULT NULL COMMENT '地点',
  `registration_type` varchar(20) COLLATE utf8mb4_general_ci DEFAULT 'PLAYER' COMMENT '报名主体类型: PLAYER (散拼), CLUB (整队)',
  `num_groups` int NOT NULL DEFAULT '2' COMMENT '需要分配的小组数量',
  `players_per_group` int DEFAULT '8' COMMENT '每组建议人数',
  `planned_game_count` int DEFAULT '1' COMMENT '计划进行的场次数量',
  `duration_per_game` int DEFAULT NULL COMMENT '每场游戏时长（分钟）',
  `total_cost` decimal(10,2) DEFAULT '0.00' COMMENT '总费用',
  `per_person_cost` decimal(10,2) DEFAULT '0.00' COMMENT '人均费用',
  `status` varchar(20) COLLATE utf8mb4_general_ci DEFAULT 'PREPARING' COMMENT 'PREPARING, PUBLISHED, REGISTRATION_CLOSED, ONGOING, MATCH_FINISHED, SETTLED, CANCELLED',
  `created_by` bigint DEFAULT NULL,
  `updated_by` bigint DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `deleted_at` datetime DEFAULT NULL COMMENT '软删除时间',
  `deleted_by` bigint DEFAULT NULL COMMENT '删除操作人用户ID',
  `groups_published` tinyint(1) NOT NULL DEFAULT '0' COMMENT '分组是否已发布：0=草稿（仅管理员可见），1=已发布（所有人可见）',
  `team_names` json DEFAULT NULL COMMENT '各队自定义名称，JSON 格式: {"0": "雄鹰队", "1": "猎豹队"}',
  `game_format` varchar(50) COLLATE utf8mb4_general_ci NOT NULL DEFAULT 'LEAGUE' COMMENT '赛制类型: LEAGUE=联赛积分制',
  `settlement_published` tinyint(1) DEFAULT '0' COMMENT '结算信息是否已确认发布',
  PRIMARY KEY (`id`),
  KEY `fk_match_tournament` (`tournament_id`),
  KEY `idx_deleted_at` (`deleted_at`),
  KEY `idx_status_deleted` (`status`,`deleted_at`),
  KEY `fk_match_deleted_by` (`deleted_by`),
  CONSTRAINT `fk_match_deleted_by` FOREIGN KEY (`deleted_by`) REFERENCES `user` (`id`) ON DELETE SET NULL,
  CONSTRAINT `fk_match_tournament` FOREIGN KEY (`tournament_id`) REFERENCES `tournament` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci COMMENT='赛事活动';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `match`
--

LOCK TABLES `match` WRITE;
/*!40000 ALTER TABLE `match` DISABLE KEYS */;
INSERT INTO `match` VALUES (7,5,'每周杯','2026-04-04 19:15:00','2026-04-04 19:15:00','2026-04-04 21:15:00','2026-04-04 15:15:00','2026-04-04 15:15:00','政悦路','PLAYER',3,6,8,15,600.00,0.00,'ONGOING',1,1,'2026-04-04 18:17:17','2026-04-04 18:17:17',NULL,NULL,1,'{\"1\": \"好朋友\"}','LEAGUE',0);
/*!40000 ALTER TABLE `match` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `match_game`
--

DROP TABLE IF EXISTS `match_game`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `match_game` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `match_id` bigint NOT NULL,
  `team_a_index` int NOT NULL COMMENT 'A队序号',
  `team_b_index` int NOT NULL COMMENT 'B队序号',
  `start_time` datetime DEFAULT NULL,
  `end_time` datetime DEFAULT NULL,
  `overtime_minutes` int DEFAULT '0',
  `score_a` int DEFAULT '0',
  `score_b` int DEFAULT '0',
  `status` varchar(20) COLLATE utf8mb4_general_ci DEFAULT 'READY' COMMENT 'READY, PLAYING, FINISHED',
  `lock_user_id` bigint DEFAULT NULL COMMENT '锁定用户',
  `lock_time` datetime DEFAULT NULL COMMENT '锁定时间',
  `created_by` bigint DEFAULT NULL,
  `updated_by` bigint DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `game_index` int NOT NULL DEFAULT '0' COMMENT '场次在赛事中的顺序序号（从0开始），用于计算预计开始时间',
  PRIMARY KEY (`id`),
  KEY `fk_game_match` (`match_id`),
  CONSTRAINT `fk_game_match` FOREIGN KEY (`match_id`) REFERENCES `match` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=24 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci COMMENT='比赛对阵场次';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `match_game`
--

LOCK TABLES `match_game` WRITE;
/*!40000 ALTER TABLE `match_game` DISABLE KEYS */;
INSERT INTO `match_game` VALUES (16,7,0,1,NULL,NULL,0,0,0,'READY',NULL,NULL,1,1,'2026-04-04 19:26:29','2026-04-04 19:26:29',0),(17,7,0,2,'2026-04-04 19:31:00','2026-04-04 19:46:00',0,0,1,'PLAYING',NULL,NULL,1,1,'2026-04-04 19:26:29','2026-04-04 19:26:29',1),(18,7,1,2,NULL,NULL,0,0,0,'READY',NULL,NULL,1,1,'2026-04-04 19:26:29','2026-04-04 19:26:29',2),(19,7,0,1,NULL,NULL,0,0,0,'READY',NULL,NULL,1,1,'2026-04-04 19:26:29','2026-04-04 19:26:29',3),(20,7,0,2,NULL,NULL,0,0,0,'READY',NULL,NULL,1,1,'2026-04-04 19:26:29','2026-04-04 19:26:29',4),(21,7,1,2,NULL,NULL,0,0,0,'READY',NULL,NULL,1,1,'2026-04-04 19:26:29','2026-04-04 19:26:29',5),(22,7,0,1,NULL,NULL,0,0,0,'READY',NULL,NULL,1,1,'2026-04-04 19:26:29','2026-04-04 19:26:29',6),(23,7,0,2,NULL,NULL,0,0,0,'READY',NULL,NULL,1,1,'2026-04-04 19:26:29','2026-04-04 19:26:29',7);
/*!40000 ALTER TABLE `match_game` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `match_goal`
--

DROP TABLE IF EXISTS `match_goal`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `match_goal` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `game_id` bigint NOT NULL,
  `team_index` int NOT NULL COMMENT '0或1',
  `scorer_id` bigint DEFAULT NULL COMMENT '进球人',
  `assistant_id` bigint DEFAULT NULL COMMENT '助攻人',
  `type` varchar(20) COLLATE utf8mb4_general_ci DEFAULT 'NORMAL' COMMENT 'NORMAL, OWN_GOAL',
  `occurred_at` datetime DEFAULT CURRENT_TIMESTAMP,
  `created_by` bigint DEFAULT NULL,
  `updated_by` bigint DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `fk_goal_game` (`game_id`),
  CONSTRAINT `fk_goal_game` FOREIGN KEY (`game_id`) REFERENCES `match_game` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=23 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci COMMENT='进球明细';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `match_goal`
--

LOCK TABLES `match_goal` WRITE;
/*!40000 ALTER TABLE `match_goal` DISABLE KEYS */;
INSERT INTO `match_goal` VALUES (22,17,2,17,20,'NORMAL','2026-04-04 11:46:01',1,1,'2026-04-04 19:46:01','2026-04-04 19:46:01');
/*!40000 ALTER TABLE `match_goal` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `match_registration`
--

DROP TABLE IF EXISTS `match_registration`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `match_registration` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `match_id` bigint NOT NULL,
  `player_id` bigint NOT NULL,
  `group_index` int DEFAULT NULL COMMENT '分配的分组序号 (0-N)',
  `status` varchar(20) COLLATE utf8mb4_general_ci DEFAULT 'REGISTERED' COMMENT 'REGISTERED, CANCELLED, NO_SHOW',
  `payment_status` varchar(20) COLLATE utf8mb4_general_ci DEFAULT 'UNPAID' COMMENT 'UNPAID, PAID',
  `is_exempt` tinyint(1) DEFAULT '0' COMMENT '是否豁免费用',
  `is_mvp` tinyint DEFAULT '0' COMMENT '是否为本场MVP',
  `created_by` bigint DEFAULT NULL,
  `updated_by` bigint DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `payment_amount` decimal(10,2) DEFAULT NULL COMMENT '实际需支付金额',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_match_player` (`match_id`,`player_id`),
  KEY `fk_reg_player` (`player_id`),
  CONSTRAINT `fk_reg_match` FOREIGN KEY (`match_id`) REFERENCES `match` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_reg_player` FOREIGN KEY (`player_id`) REFERENCES `player` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=44 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci COMMENT='赛事报名表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `match_registration`
--

LOCK TABLES `match_registration` WRITE;
/*!40000 ALTER TABLE `match_registration` DISABLE KEYS */;
INSERT INTO `match_registration` VALUES (28,7,2,0,'REGISTERED','UNPAID',0,0,1,1,'2026-04-04 18:17:59','2026-04-04 19:25:14',NULL),(29,7,7,2,'REGISTERED','UNPAID',0,0,1,1,'2026-04-04 18:17:59','2026-04-04 19:25:14',NULL),(30,7,8,0,'REGISTERED','UNPAID',0,0,1,1,'2026-04-04 18:17:59','2026-04-04 19:25:14',NULL),(31,7,11,1,'REGISTERED','UNPAID',0,0,1,1,'2026-04-04 18:17:59','2026-04-04 19:25:14',NULL),(32,7,13,2,'REGISTERED','UNPAID',0,0,1,1,'2026-04-04 18:17:59','2026-04-04 19:25:14',NULL),(33,7,14,0,'REGISTERED','UNPAID',0,0,1,1,'2026-04-04 18:17:59','2026-04-04 19:25:14',NULL),(34,7,15,1,'REGISTERED','UNPAID',0,0,1,1,'2026-04-04 18:17:59','2026-04-04 19:25:14',NULL),(35,7,16,1,'REGISTERED','UNPAID',0,0,1,1,'2026-04-04 18:17:59','2026-04-04 19:25:14',NULL),(36,7,17,2,'REGISTERED','UNPAID',0,0,1,1,'2026-04-04 18:17:59','2026-04-04 19:25:14',NULL),(37,7,18,0,'REGISTERED','UNPAID',0,0,1,1,'2026-04-04 18:17:59','2026-04-04 19:25:14',NULL),(38,7,19,0,'REGISTERED','UNPAID',0,0,1,1,'2026-04-04 18:17:59','2026-04-04 19:25:14',NULL),(39,7,20,2,'REGISTERED','UNPAID',0,0,1,1,'2026-04-04 18:17:59','2026-04-04 19:25:14',NULL),(40,7,21,2,'REGISTERED','UNPAID',0,0,1,1,'2026-04-04 18:17:59','2026-04-04 19:25:14',NULL),(41,7,22,1,'REGISTERED','UNPAID',0,0,1,1,'2026-04-04 18:17:59','2026-04-04 19:25:14',NULL),(42,7,23,1,'REGISTERED','UNPAID',0,0,1,1,'2026-04-04 18:17:59','2026-04-04 19:25:14',NULL),(43,7,24,1,'REGISTERED','UNPAID',0,0,1,1,'2026-04-04 18:17:59','2026-04-04 19:25:14',NULL);
/*!40000 ALTER TABLE `match_registration` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `match_score_log`
--

DROP TABLE IF EXISTS `match_score_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `match_score_log` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `game_id` bigint NOT NULL,
  `score_a` int NOT NULL,
  `score_b` int NOT NULL,
  `type` varchar(20) COLLATE utf8mb4_general_ci DEFAULT 'GOAL' COMMENT 'GOAL, MANUAL, CORRECTION',
  `created_by` bigint DEFAULT NULL,
  `updated_by` bigint DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=39 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci COMMENT='比分变动流水';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `match_score_log`
--

LOCK TABLES `match_score_log` WRITE;
/*!40000 ALTER TABLE `match_score_log` DISABLE KEYS */;
INSERT INTO `match_score_log` VALUES (37,17,0,0,'STARTED',1,1,'2026-04-04 19:31:32','2026-04-04 19:31:32'),(38,17,0,1,'GOAL',1,1,'2026-04-04 19:46:01','2026-04-04 19:46:01');
/*!40000 ALTER TABLE `match_score_log` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `player`
--

DROP TABLE IF EXISTS `player`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `player` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `user_id` bigint DEFAULT NULL COMMENT '关联用户ID',
  `nickname` varchar(64) COLLATE utf8mb4_general_ci NOT NULL COMMENT '球场昵称',
  `position` varchar(20) COLLATE utf8mb4_general_ci DEFAULT 'UNKNOWN' COMMENT '擅长位置：GK, DF, MF, FW',
  `age` int DEFAULT NULL COMMENT '年龄',
  `preferred_foot` varchar(10) COLLATE utf8mb4_general_ci DEFAULT 'RIGHT' COMMENT '擅长脚：LEFT, RIGHT, BOTH',
  `gender` varchar(10) COLLATE utf8mb4_general_ci DEFAULT NULL COMMENT '性别: MALE / FEMALE',
  `height` int DEFAULT NULL COMMENT '身高(cm)',
  `status` tinyint NOT NULL DEFAULT '1' COMMENT '状态：1-活跃，0-隐退',
  `created_by` bigint DEFAULT NULL,
  `updated_by` bigint DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_user_id` (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=25 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci COMMENT='球员档案';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `player`
--

LOCK TABLES `player` WRITE;
/*!40000 ALTER TABLE `player` DISABLE KEYS */;
INSERT INTO `player` VALUES (1,1,'老大哥','MF',35,'BOTH',NULL,NULL,1,NULL,1,'2026-03-29 22:57:04','2026-03-30 12:55:45'),(2,6,'陈越','MF',37,'RIGHT','MALE',171,1,1,1,'2026-03-30 10:17:58','2026-03-30 12:55:45'),(3,7,'test','MF',25,'RIGHT','MALE',175,1,1,1,'2026-03-30 12:50:22','2026-03-30 12:50:22'),(4,8,'托尔斯泰','MF',25,'RIGHT','MALE',175,1,7,7,'2026-03-30 12:50:44','2026-03-30 12:50:44'),(5,9,'test2','FW',25,'RIGHT','MALE',175,1,7,7,'2026-03-30 12:51:04','2026-03-30 12:51:04'),(6,10,'Mararino','FW',36,'RIGHT','MALE',176,1,1,1,'2026-03-30 12:58:38','2026-03-30 12:58:38'),(7,11,'林','FW',25,'BOTH','MALE',175,1,1,1,'2026-03-30 13:04:35','2026-03-30 13:04:35'),(8,12,'alvin','DF',43,'RIGHT','MALE',175,1,1,1,'2026-03-30 13:33:44','2026-03-30 13:33:44'),(9,13,'林','FW',40,'BOTH','MALE',176,1,NULL,NULL,'2026-03-30 20:45:01','2026-03-30 20:45:01'),(10,14,'大海','DF',41,'RIGHT','MALE',175,1,NULL,NULL,'2026-03-30 20:52:29','2026-03-30 20:52:29'),(11,15,'英扎吉','FW',18,'RIGHT','MALE',177,1,NULL,NULL,'2026-03-30 21:07:14','2026-03-30 21:07:14'),(12,16,'天生','MF',22,'RIGHT','MALE',179,1,NULL,NULL,'2026-03-30 21:32:43','2026-03-30 21:32:43'),(13,17,'何队','MF',41,'BOTH','MALE',174,1,NULL,NULL,'2026-03-30 23:32:55','2026-03-30 23:32:55'),(14,18,'黄吉','MF',25,'RIGHT','MALE',175,1,NULL,NULL,'2026-04-04 17:57:17','2026-04-04 17:57:17'),(15,19,'沈雪天','MF',25,'RIGHT','MALE',175,1,NULL,NULL,'2026-04-04 17:59:27','2026-04-04 17:59:27'),(16,20,'景','MF',25,'RIGHT','MALE',175,1,NULL,NULL,'2026-04-04 18:00:09','2026-04-04 18:00:09'),(17,21,'黄杰晶','MF',25,'RIGHT','MALE',175,1,NULL,NULL,'2026-04-04 18:04:32','2026-04-04 18:04:32'),(18,22,'教练','MF',25,'RIGHT','MALE',175,1,NULL,NULL,'2026-04-04 18:05:37','2026-04-04 18:05:37'),(19,23,'xjx','MF',25,'RIGHT','MALE',175,1,NULL,NULL,'2026-04-04 18:06:40','2026-04-04 18:06:40'),(20,24,'王藩翰','MF',25,'RIGHT','MALE',175,1,NULL,NULL,'2026-04-04 18:07:54','2026-04-04 18:07:54'),(21,25,'moris','MF',25,'RIGHT','MALE',175,1,NULL,NULL,'2026-04-04 18:08:53','2026-04-04 18:08:53'),(22,26,'阿穆','MF',25,'RIGHT','MALE',175,1,NULL,NULL,'2026-04-04 18:09:42','2026-04-04 18:09:42'),(23,27,'赵赶鹅','MF',25,'RIGHT','MALE',175,1,NULL,NULL,'2026-04-04 18:11:04','2026-04-04 18:11:04'),(24,28,'阿良','MF',25,'RIGHT','MALE',175,1,NULL,NULL,'2026-04-04 18:12:09','2026-04-04 18:12:09');
/*!40000 ALTER TABLE `player` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `player_mutual_rating`
--

DROP TABLE IF EXISTS `player_mutual_rating`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `player_mutual_rating` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `match_id` bigint NOT NULL,
  `from_player_id` bigint NOT NULL,
  `to_player_id` bigint NOT NULL,
  `rating_skill` decimal(3,1) DEFAULT NULL,
  `rating_fitness` decimal(3,1) DEFAULT NULL,
  `rating_attitude` decimal(3,1) DEFAULT NULL,
  `rating_vision` decimal(3,1) DEFAULT NULL,
  `is_mvp_vote` tinyint DEFAULT '0',
  `comment` varchar(255) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `created_by` bigint DEFAULT NULL,
  `updated_by` bigint DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `fk_rate_match` (`match_id`),
  CONSTRAINT `fk_rate_match` FOREIGN KEY (`match_id`) REFERENCES `match` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci COMMENT='球员互评';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `player_mutual_rating`
--

LOCK TABLES `player_mutual_rating` WRITE;
/*!40000 ALTER TABLE `player_mutual_rating` DISABLE KEYS */;
/*!40000 ALTER TABLE `player_mutual_rating` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `player_rating_history`
--

DROP TABLE IF EXISTS `player_rating_history`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `player_rating_history` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `player_id` bigint NOT NULL,
  `tournament_id` bigint DEFAULT NULL COMMENT '所属 Tournament',
  `match_id` bigint DEFAULT NULL,
  `dimension` varchar(20) DEFAULT 'TOTAL' COMMENT 'SKILL, PERFORMANCE, ENGAGEMENT, TOTAL, DECAY, ADMIN',
  `source_type` varchar(30) DEFAULT 'LEGACY' COMMENT 'MATCH_SETTLEMENT, INACTIVITY_DECAY, RETURN_BONUS, ADMIN_CORRECTION, INITIALIZATION, LEGACY',
  `old_rating` decimal(10,2) DEFAULT NULL,
  `new_rating` decimal(10,2) DEFAULT NULL,
  `old_value` decimal(10,2) DEFAULT NULL,
  `new_value` decimal(10,2) DEFAULT NULL,
  `delta` decimal(10,2) DEFAULT NULL,
  `change_reason` varchar(50) DEFAULT NULL,
  `reason_code` varchar(50) DEFAULT NULL,
  `reason_detail` varchar(255) DEFAULT NULL,
  `operator_user_id` bigint DEFAULT NULL,
  `create_time` datetime DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_player_id` (`player_id`),
  KEY `idx_prh_dimension_source` (`dimension`,`source_type`),
  KEY `idx_prh_player_created` (`player_id`,`create_time`),
  KEY `idx_prh_tournament` (`tournament_id`)
) ENGINE=InnoDB AUTO_INCREMENT=217 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `player_rating_history`
--

LOCK TABLES `player_rating_history` WRITE;
/*!40000 ALTER TABLE `player_rating_history` DISABLE KEYS */;
INSERT INTO `player_rating_history` VALUES (2,2,NULL,NULL,'TOTAL','INITIALIZATION',5.00,5.00,5.00,5.00,0.00,'INITIALIZATION','INITIALIZATION','player-bootstrap',NULL,'2026-03-30 10:17:58'),(4,3,NULL,NULL,'TOTAL','INITIALIZATION',5.00,5.00,5.00,5.00,0.00,'INITIALIZATION','INITIALIZATION','player-bootstrap',NULL,'2026-03-30 12:50:22'),(5,4,NULL,NULL,'TOTAL','INITIALIZATION',5.00,5.00,5.00,5.00,0.00,'INITIALIZATION','INITIALIZATION','player-bootstrap',NULL,'2026-03-30 12:50:44'),(6,5,NULL,NULL,'TOTAL','INITIALIZATION',5.00,5.00,5.00,5.00,0.00,'INITIALIZATION','INITIALIZATION','player-bootstrap',NULL,'2026-03-30 12:51:04'),(34,6,NULL,NULL,'TOTAL','INITIALIZATION',5.00,5.00,5.00,5.00,0.00,'INITIALIZATION','INITIALIZATION','player-bootstrap',NULL,'2026-03-30 12:58:38'),(40,7,NULL,NULL,'TOTAL','INITIALIZATION',5.00,5.00,5.00,5.00,0.00,'INITIALIZATION','INITIALIZATION','player-bootstrap',NULL,'2026-03-30 13:04:35'),(74,8,NULL,NULL,'TOTAL','INITIALIZATION',5.00,5.00,5.00,5.00,0.00,'INITIALIZATION','INITIALIZATION','player-bootstrap',NULL,'2026-03-30 13:33:44'),(196,1,5,NULL,'TOTAL','INITIALIZATION',5.00,5.00,5.00,5.00,0.00,'INITIALIZATION','INITIALIZATION','tournament-join-bootstrap',NULL,'2026-03-31 23:22:37'),(197,13,5,NULL,'TOTAL','INITIALIZATION',5.00,5.00,5.00,5.00,0.00,'INITIALIZATION','INITIALIZATION','tournament-join-bootstrap',NULL,'2026-03-31 23:25:29'),(198,12,5,NULL,'TOTAL','INITIALIZATION',5.00,5.00,5.00,5.00,0.00,'INITIALIZATION','INITIALIZATION','tournament-join-bootstrap',NULL,'2026-03-31 23:25:30'),(199,11,5,NULL,'TOTAL','INITIALIZATION',5.00,5.00,5.00,5.00,0.00,'INITIALIZATION','INITIALIZATION','tournament-join-bootstrap',NULL,'2026-03-31 23:25:30'),(200,10,5,NULL,'TOTAL','INITIALIZATION',5.00,5.00,5.00,5.00,0.00,'INITIALIZATION','INITIALIZATION','tournament-join-bootstrap',NULL,'2026-03-31 23:25:30'),(201,9,5,NULL,'TOTAL','INITIALIZATION',5.00,5.00,5.00,5.00,0.00,'INITIALIZATION','INITIALIZATION','tournament-join-bootstrap',NULL,'2026-03-31 23:25:30'),(202,8,5,NULL,'TOTAL','INITIALIZATION',5.00,5.00,5.00,5.00,0.00,'INITIALIZATION','INITIALIZATION','tournament-join-bootstrap',NULL,'2026-03-31 23:25:31'),(203,7,5,NULL,'TOTAL','INITIALIZATION',5.00,5.00,5.00,5.00,0.00,'INITIALIZATION','INITIALIZATION','tournament-join-bootstrap',NULL,'2026-03-31 23:25:31'),(204,6,5,NULL,'TOTAL','INITIALIZATION',5.00,5.00,5.00,5.00,0.00,'INITIALIZATION','INITIALIZATION','tournament-join-bootstrap',NULL,'2026-03-31 23:25:31'),(205,14,5,NULL,'TOTAL','INITIALIZATION',5.00,5.00,5.00,5.00,0.00,'INITIALIZATION','INITIALIZATION','tournament-join-bootstrap',NULL,'2026-04-04 17:57:21'),(206,2,5,NULL,'TOTAL','INITIALIZATION',5.00,5.00,5.00,5.00,0.00,'INITIALIZATION','INITIALIZATION','tournament-join-bootstrap',NULL,'2026-04-04 17:58:27'),(207,15,5,NULL,'TOTAL','INITIALIZATION',5.00,5.00,5.00,5.00,0.00,'INITIALIZATION','INITIALIZATION','tournament-join-bootstrap',NULL,'2026-04-04 17:59:34'),(208,16,5,NULL,'TOTAL','INITIALIZATION',5.00,5.00,5.00,5.00,0.00,'INITIALIZATION','INITIALIZATION','tournament-join-bootstrap',NULL,'2026-04-04 18:00:14'),(209,17,5,NULL,'TOTAL','INITIALIZATION',5.00,5.00,5.00,5.00,0.00,'INITIALIZATION','INITIALIZATION','tournament-join-bootstrap',NULL,'2026-04-04 18:04:43'),(210,18,5,NULL,'TOTAL','INITIALIZATION',5.00,5.00,5.00,5.00,0.00,'INITIALIZATION','INITIALIZATION','tournament-join-bootstrap',NULL,'2026-04-04 18:05:42'),(211,19,5,NULL,'TOTAL','INITIALIZATION',5.00,5.00,5.00,5.00,0.00,'INITIALIZATION','INITIALIZATION','tournament-join-bootstrap',NULL,'2026-04-04 18:06:48'),(212,20,5,NULL,'TOTAL','INITIALIZATION',5.00,5.00,5.00,5.00,0.00,'INITIALIZATION','INITIALIZATION','tournament-join-bootstrap',NULL,'2026-04-04 18:07:58'),(213,21,5,NULL,'TOTAL','INITIALIZATION',5.00,5.00,5.00,5.00,0.00,'INITIALIZATION','INITIALIZATION','tournament-join-bootstrap',NULL,'2026-04-04 18:08:57'),(214,22,5,NULL,'TOTAL','INITIALIZATION',5.00,5.00,5.00,5.00,0.00,'INITIALIZATION','INITIALIZATION','tournament-join-bootstrap',NULL,'2026-04-04 18:09:46'),(215,23,5,NULL,'TOTAL','INITIALIZATION',5.00,5.00,5.00,5.00,0.00,'INITIALIZATION','INITIALIZATION','tournament-join-bootstrap',NULL,'2026-04-04 18:11:08'),(216,24,5,NULL,'TOTAL','INITIALIZATION',5.00,5.00,5.00,5.00,0.00,'INITIALIZATION','INITIALIZATION','tournament-join-bootstrap',NULL,'2026-04-04 18:12:17');
/*!40000 ALTER TABLE `player_rating_history` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `player_rating_profile`
--

DROP TABLE IF EXISTS `player_rating_profile`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `player_rating_profile` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `player_id` bigint NOT NULL,
  `tournament_id` bigint DEFAULT NULL COMMENT '所属 Tournament',
  `skill_rating` decimal(4,2) NOT NULL DEFAULT '5.00',
  `performance_rating` decimal(4,2) NOT NULL DEFAULT '5.00',
  `engagement_rating` decimal(4,2) NOT NULL DEFAULT '5.00',
  `provisional_matches` int NOT NULL DEFAULT '0',
  `appearance_count` int NOT NULL DEFAULT '0',
  `active_streak_weeks` int NOT NULL DEFAULT '0',
  `last_attendance_time` datetime DEFAULT NULL,
  `last_decay_time` datetime DEFAULT NULL,
  `rating_version` tinyint NOT NULL DEFAULT '2',
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_profile_player_tournament` (`player_id`,`tournament_id`),
  KEY `idx_profile_last_attendance_time` (`last_attendance_time`),
  CONSTRAINT `fk_profile_player` FOREIGN KEY (`player_id`) REFERENCES `player` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=45 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci COMMENT='球员评分档案';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `player_rating_profile`
--

LOCK TABLES `player_rating_profile` WRITE;
/*!40000 ALTER TABLE `player_rating_profile` DISABLE KEYS */;
INSERT INTO `player_rating_profile` VALUES (2,2,NULL,5.00,5.00,5.00,0,0,0,NULL,NULL,2,'2026-03-30 10:17:58','2026-03-30 10:17:58'),(4,3,NULL,5.00,5.00,5.00,0,0,0,NULL,NULL,2,'2026-03-30 12:50:21','2026-03-30 12:50:21'),(5,4,NULL,5.00,5.00,5.00,0,0,0,NULL,NULL,2,'2026-03-30 12:50:43','2026-03-30 12:50:43'),(6,5,NULL,5.00,5.00,5.00,0,0,0,NULL,NULL,2,'2026-03-30 12:51:03','2026-03-30 12:51:03'),(10,6,NULL,5.00,5.00,5.00,0,0,0,NULL,NULL,2,'2026-03-30 12:58:37','2026-03-30 12:58:37'),(12,7,NULL,5.00,5.00,5.00,0,0,0,NULL,NULL,2,'2026-03-30 13:04:35','2026-03-30 13:04:35'),(14,8,NULL,5.00,5.00,5.00,0,0,0,NULL,NULL,2,'2026-03-30 13:33:44','2026-03-30 13:33:44'),(24,1,5,5.00,5.00,5.00,0,0,0,NULL,NULL,2,'2026-03-31 23:22:37','2026-03-31 23:22:37'),(25,13,5,5.00,5.00,5.00,0,0,0,NULL,NULL,2,'2026-03-31 23:25:29','2026-03-31 23:25:29'),(26,12,5,5.00,5.00,5.00,0,0,0,NULL,NULL,2,'2026-03-31 23:25:29','2026-03-31 23:25:29'),(27,11,5,5.00,5.00,5.00,0,0,0,NULL,NULL,2,'2026-03-31 23:25:29','2026-03-31 23:25:29'),(28,10,5,5.00,5.00,5.00,0,0,0,NULL,NULL,2,'2026-03-31 23:25:29','2026-03-31 23:25:29'),(29,9,5,5.00,5.00,5.00,0,0,0,NULL,NULL,2,'2026-03-31 23:25:30','2026-03-31 23:25:30'),(30,8,5,5.00,5.00,5.00,0,0,0,NULL,NULL,2,'2026-03-31 23:25:30','2026-03-31 23:25:30'),(31,7,5,5.00,5.00,5.00,0,0,0,NULL,NULL,2,'2026-03-31 23:25:30','2026-03-31 23:25:30'),(32,6,5,5.00,5.00,5.00,0,0,0,NULL,NULL,2,'2026-03-31 23:25:30','2026-03-31 23:25:30'),(33,14,5,5.00,5.00,5.00,0,0,0,NULL,NULL,2,'2026-04-04 17:57:21','2026-04-04 17:57:21'),(34,2,5,5.00,5.00,5.00,0,0,0,NULL,NULL,2,'2026-04-04 17:58:27','2026-04-04 17:58:27'),(35,15,5,5.00,5.00,5.00,0,0,0,NULL,NULL,2,'2026-04-04 17:59:33','2026-04-04 17:59:33'),(36,16,5,5.00,5.00,5.00,0,0,0,NULL,NULL,2,'2026-04-04 18:00:13','2026-04-04 18:00:13'),(37,17,5,5.00,5.00,5.00,0,0,0,NULL,NULL,2,'2026-04-04 18:04:42','2026-04-04 18:04:42'),(38,18,5,5.00,5.00,5.00,0,0,0,NULL,NULL,2,'2026-04-04 18:05:41','2026-04-04 18:05:41'),(39,19,5,5.00,5.00,5.00,0,0,0,NULL,NULL,2,'2026-04-04 18:06:47','2026-04-04 18:06:47'),(40,20,5,5.00,5.00,5.00,0,0,0,NULL,NULL,2,'2026-04-04 18:07:58','2026-04-04 18:07:58'),(41,21,5,5.00,5.00,5.00,0,0,0,NULL,NULL,2,'2026-04-04 18:08:57','2026-04-04 18:08:57'),(42,22,5,5.00,5.00,5.00,0,0,0,NULL,NULL,2,'2026-04-04 18:09:45','2026-04-04 18:09:45'),(43,23,5,5.00,5.00,5.00,0,0,0,NULL,NULL,2,'2026-04-04 18:11:08','2026-04-04 18:11:08'),(44,24,5,5.00,5.00,5.00,0,0,0,NULL,NULL,2,'2026-04-04 18:12:17','2026-04-04 18:12:17');
/*!40000 ALTER TABLE `player_rating_profile` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `player_stat`
--

DROP TABLE IF EXISTS `player_stat`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `player_stat` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `player_id` bigint NOT NULL,
  `tournament_id` bigint DEFAULT NULL COMMENT '所属 Tournament',
  `total_matches` int DEFAULT '0',
  `wins` int DEFAULT '0',
  `draws` int DEFAULT '0',
  `losses` int DEFAULT '0',
  `total_goals` int DEFAULT '0',
  `total_assists` int DEFAULT '0',
  `total_mvps` int DEFAULT '0',
  `clean_sheets` int DEFAULT '0',
  `update_time` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_stat_player_tournament` (`player_id`,`tournament_id`)
) ENGINE=InnoDB AUTO_INCREMENT=44 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `player_stat`
--

LOCK TABLES `player_stat` WRITE;
/*!40000 ALTER TABLE `player_stat` DISABLE KEYS */;
INSERT INTO `player_stat` VALUES (23,1,5,0,0,0,0,0,0,0,0,'2026-03-31 23:22:37'),(24,13,5,0,0,0,0,0,0,0,0,'2026-03-31 23:25:29'),(25,12,5,0,0,0,0,0,0,0,0,'2026-03-31 23:25:29'),(26,11,5,0,0,0,0,0,0,0,0,'2026-03-31 23:25:29'),(27,10,5,0,0,0,0,0,0,0,0,'2026-03-31 23:25:30'),(28,9,5,0,0,0,0,0,0,0,0,'2026-03-31 23:25:30'),(29,8,5,0,0,0,0,0,0,0,0,'2026-03-31 23:25:30'),(30,7,5,0,0,0,0,0,0,0,0,'2026-03-31 23:25:30'),(31,6,5,0,0,0,0,0,0,0,0,'2026-03-31 23:25:30'),(32,14,5,0,0,0,0,0,0,0,0,'2026-04-04 17:57:21'),(33,2,5,0,0,0,0,0,0,0,0,'2026-04-04 17:58:27'),(34,15,5,0,0,0,0,0,0,0,0,'2026-04-04 17:59:33'),(35,16,5,0,0,0,0,0,0,0,0,'2026-04-04 18:00:13'),(36,17,5,0,0,0,0,0,0,0,0,'2026-04-04 18:04:42'),(37,18,5,0,0,0,0,0,0,0,0,'2026-04-04 18:05:41'),(38,19,5,0,0,0,0,0,0,0,0,'2026-04-04 18:06:47'),(39,20,5,0,0,0,0,0,0,0,0,'2026-04-04 18:07:58'),(40,21,5,0,0,0,0,0,0,0,0,'2026-04-04 18:08:57'),(41,22,5,0,0,0,0,0,0,0,0,'2026-04-04 18:09:45'),(42,23,5,0,0,0,0,0,0,0,0,'2026-04-04 18:11:08'),(43,24,5,0,0,0,0,0,0,0,0,'2026-04-04 18:12:17');
/*!40000 ALTER TABLE `player_stat` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `role`
--

DROP TABLE IF EXISTS `role`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `role` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `name` varchar(50) COLLATE utf8mb4_general_ci NOT NULL COMMENT '角色名称：admin, player, coach 等',
  `description` varchar(100) COLLATE utf8mb4_general_ci DEFAULT NULL COMMENT '角色描述',
  `created_by` bigint DEFAULT NULL,
  `updated_by` bigint DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci COMMENT='系统角色表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `role`
--

LOCK TABLES `role` WRITE;
/*!40000 ALTER TABLE `role` DISABLE KEYS */;
INSERT INTO `role` VALUES (1,'admin','系统管理员',NULL,NULL,'2026-03-29 22:57:03','2026-03-29 22:57:03'),(2,'player','球员',NULL,NULL,'2026-03-29 22:57:03','2026-03-29 22:57:03'),(3,'platform_admin','平台超级管理员',NULL,NULL,'2026-03-29 22:57:06','2026-03-29 22:57:06');
/*!40000 ALTER TABLE `role` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `system_status`
--

DROP TABLE IF EXISTS `system_status`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `system_status` (
  `config_key` varchar(64) COLLATE utf8mb4_general_ci NOT NULL,
  `config_value` varchar(255) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `description` varchar(255) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `created_by` bigint DEFAULT NULL,
  `updated_by` bigint DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`config_key`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci COMMENT='系统配置与状态快照';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `system_status`
--

LOCK TABLES `system_status` WRITE;
/*!40000 ALTER TABLE `system_status` DISABLE KEYS */;
INSERT INTO `system_status` VALUES ('LAST_DECAY_RUN_TIME','2026-03-30 10:16:56','球员评分衰减任务最后执行时间',NULL,1,'2026-03-29 22:57:03','2026-03-29 22:57:03');
/*!40000 ALTER TABLE `system_status` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tournament`
--

DROP TABLE IF EXISTS `tournament`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `tournament` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `name` varchar(128) COLLATE utf8mb4_general_ci NOT NULL COMMENT '赛事名称',
  `description` text COLLATE utf8mb4_general_ci COMMENT '赛事描述',
  `status` tinyint NOT NULL DEFAULT '1' COMMENT '1:活跃, 0:归档',
  `join_mode` varchar(20) COLLATE utf8mb4_general_ci NOT NULL DEFAULT 'OPEN' COMMENT '加入方式: OPEN / APPROVAL',
  `logo` varchar(255) COLLATE utf8mb4_general_ci DEFAULT NULL COMMENT 'Tournament 图标 URL',
  `max_players` int DEFAULT NULL COMMENT '最大球员数限制',
  `created_by` bigint DEFAULT NULL,
  `updated_by` bigint DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `deleted_at` datetime DEFAULT NULL COMMENT '软删除时间',
  `deleted_by` bigint DEFAULT NULL COMMENT '删除操作人用户ID',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci COMMENT='赛事(租户)';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tournament`
--

LOCK TABLES `tournament` WRITE;
/*!40000 ALTER TABLE `tournament` DISABLE KEYS */;
INSERT INTO `tournament` VALUES (5,'2026赛季每周杯','',1,'OPEN',NULL,NULL,1,1,'2026-03-31 23:22:33','2026-03-31 23:22:33',NULL,NULL);
/*!40000 ALTER TABLE `tournament` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tournament_admin`
--

DROP TABLE IF EXISTS `tournament_admin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `tournament_admin` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `tournament_id` bigint NOT NULL,
  `user_id` bigint NOT NULL,
  `created_by` bigint DEFAULT NULL,
  `updated_by` bigint DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_tournament_user` (`tournament_id`,`user_id`),
  KEY `fk_ta_user` (`user_id`),
  CONSTRAINT `fk_ta_tournament` FOREIGN KEY (`tournament_id`) REFERENCES `tournament` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_ta_user` FOREIGN KEY (`user_id`) REFERENCES `user` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci COMMENT='Tournament 管理员关联表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tournament_admin`
--

LOCK TABLES `tournament_admin` WRITE;
/*!40000 ALTER TABLE `tournament_admin` DISABLE KEYS */;
INSERT INTO `tournament_admin` VALUES (2,5,17,1,1,'2026-03-31 23:25:38','2026-03-31 23:25:38');
/*!40000 ALTER TABLE `tournament_admin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tournament_player`
--

DROP TABLE IF EXISTS `tournament_player`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `tournament_player` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `tournament_id` bigint NOT NULL COMMENT '所属 Tournament',
  `player_id` bigint NOT NULL COMMENT '球员ID（全局）',
  `club_id` bigint DEFAULT NULL COMMENT '在该 Tournament 下所属俱乐部',
  `last_match_time` datetime DEFAULT NULL COMMENT '该 Tournament 下最后比赛时间',
  `last_attendance_time` datetime DEFAULT NULL COMMENT '该 Tournament 下最后出勤时间',
  `join_status` varchar(20) COLLATE utf8mb4_general_ci NOT NULL DEFAULT 'ACTIVE' COMMENT 'PENDING / ACTIVE / LEFT',
  `status` tinyint NOT NULL DEFAULT '1' COMMENT '1=活跃, 0=隐退',
  `created_by` bigint DEFAULT NULL,
  `updated_by` bigint DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_tournament_player` (`tournament_id`,`player_id`),
  KEY `idx_tp_player` (`player_id`),
  CONSTRAINT `fk_tp_player` FOREIGN KEY (`player_id`) REFERENCES `player` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_tp_tournament` FOREIGN KEY (`tournament_id`) REFERENCES `tournament` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=38 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci COMMENT='球员-Tournament 注册关系及 Tournament 维度数据';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tournament_player`
--

LOCK TABLES `tournament_player` WRITE;
/*!40000 ALTER TABLE `tournament_player` DISABLE KEYS */;
INSERT INTO `tournament_player` VALUES (17,5,1,NULL,NULL,NULL,'ACTIVE',1,1,1,'2026-03-31 23:22:37','2026-03-31 23:22:37'),(18,5,13,NULL,NULL,NULL,'ACTIVE',1,1,1,'2026-03-31 23:25:29','2026-03-31 23:25:29'),(19,5,12,NULL,NULL,NULL,'ACTIVE',1,1,1,'2026-03-31 23:25:30','2026-03-31 23:25:30'),(20,5,11,NULL,NULL,NULL,'ACTIVE',1,1,1,'2026-03-31 23:25:30','2026-03-31 23:25:30'),(21,5,10,NULL,NULL,NULL,'ACTIVE',1,1,1,'2026-03-31 23:25:30','2026-03-31 23:25:30'),(22,5,9,NULL,NULL,NULL,'ACTIVE',1,1,1,'2026-03-31 23:25:30','2026-03-31 23:25:30'),(23,5,8,NULL,NULL,NULL,'ACTIVE',1,1,1,'2026-03-31 23:25:30','2026-03-31 23:25:30'),(24,5,7,NULL,NULL,NULL,'ACTIVE',1,1,1,'2026-03-31 23:25:31','2026-03-31 23:25:31'),(25,5,6,NULL,NULL,NULL,'ACTIVE',1,1,1,'2026-03-31 23:25:31','2026-03-31 23:25:31'),(26,5,14,NULL,NULL,NULL,'ACTIVE',1,18,18,'2026-04-04 17:57:21','2026-04-04 17:57:21'),(27,5,2,NULL,NULL,NULL,'ACTIVE',1,6,6,'2026-04-04 17:58:27','2026-04-04 17:58:27'),(28,5,15,NULL,NULL,NULL,'ACTIVE',1,19,19,'2026-04-04 17:59:34','2026-04-04 17:59:34'),(29,5,16,NULL,NULL,NULL,'ACTIVE',1,20,20,'2026-04-04 18:00:14','2026-04-04 18:00:14'),(30,5,17,NULL,NULL,NULL,'ACTIVE',1,21,21,'2026-04-04 18:04:43','2026-04-04 18:04:43'),(31,5,18,NULL,NULL,NULL,'ACTIVE',1,22,22,'2026-04-04 18:05:42','2026-04-04 18:05:42'),(32,5,19,NULL,NULL,NULL,'ACTIVE',1,23,23,'2026-04-04 18:06:48','2026-04-04 18:06:48'),(33,5,20,NULL,NULL,NULL,'ACTIVE',1,24,24,'2026-04-04 18:07:58','2026-04-04 18:07:58'),(34,5,21,NULL,NULL,NULL,'ACTIVE',1,25,25,'2026-04-04 18:08:57','2026-04-04 18:08:57'),(35,5,22,NULL,NULL,NULL,'ACTIVE',1,26,26,'2026-04-04 18:09:46','2026-04-04 18:09:46'),(36,5,23,NULL,NULL,NULL,'ACTIVE',1,27,27,'2026-04-04 18:11:08','2026-04-04 18:11:08'),(37,5,24,NULL,NULL,NULL,'ACTIVE',1,28,28,'2026-04-04 18:12:17','2026-04-04 18:12:17');
/*!40000 ALTER TABLE `tournament_player` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user`
--

DROP TABLE IF EXISTS `user`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `user` (
  `id` bigint NOT NULL AUTO_INCREMENT COMMENT '主键ID',
  `username` varchar(64) COLLATE utf8mb4_general_ci NOT NULL COMMENT '用户名',
  `password` varchar(128) COLLATE utf8mb4_general_ci NOT NULL COMMENT '密码',
  `salt` varchar(64) COLLATE utf8mb4_general_ci NOT NULL COMMENT '盐值',
  `real_name` varchar(64) COLLATE utf8mb4_general_ci DEFAULT NULL COMMENT '真实姓名',
  `status` tinyint NOT NULL DEFAULT '1' COMMENT '状态：1-正常，0-禁用',
  `created_by` bigint DEFAULT NULL,
  `updated_by` bigint DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_username` (`username`)
) ENGINE=InnoDB AUTO_INCREMENT=29 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci COMMENT='用户账号表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user`
--

LOCK TABLES `user` WRITE;
/*!40000 ALTER TABLE `user` DISABLE KEYS */;
INSERT INTO `user` VALUES (1,'admin','e8054c3e4fb91c8476925fd48134ebbf38ee437e72f752ae0d3dcc465dd4f252','admin_salt','系统管理员',1,NULL,NULL,'2026-03-29 22:57:04','2026-03-29 22:57:04'),(6,'cade','194df1275c4132d98af82d8e328a3fdf11f6ea6aa66a85460cc14ec2a56263fe','83ae674e183140e282d8ef492ce27595','陈越',1,1,1,'2026-03-30 10:17:58','2026-03-30 10:17:58'),(7,'test','74fdf81a4f858a6181f0e016af33318982e8ab852cba039fb9462850cd58faca','e376550877e24806b3e3dfa86afd4764','test',1,1,1,'2026-03-30 12:50:22','2026-03-30 12:50:22'),(8,'test2','ed856d44048140126e9778878bbb2bc45302b28767cb8b12a94acac49d705173','29dd522edc1a49209c79f997036a5e36','test2',1,7,7,'2026-03-30 12:50:44','2026-03-30 12:50:44'),(9,'test3','05227daed436f12acb2ac3914adcbdf805d675dbda2eb2d0b18dd1a5976c069b','a503368b97974ab9b72a2f01b6abd9cd','test2',1,7,7,'2026-03-30 12:51:04','2026-03-30 12:51:04'),(10,'Marsarino','472a7186420c9a36f82d39bf22f6d5c0cdfb6a549ef1cde2cc60a0765f4ac138','28b336f36d02480599a0ccd7f04b20d5','赵骏',1,1,1,'2026-03-30 12:58:38','2026-03-30 12:58:38'),(11,'ivan','c2cc61383cb1d55c97e7cd2413c451a0ad8bddcb8249e0dbd6a117d46c6929c9','19492d5f1f7b43d790c77d6de3f4c608','林一凡',1,1,1,'2026-03-30 13:04:35','2026-03-30 13:04:35'),(12,'alvin','69510ab8f52fbf9c5c6a31a7409597453e94f197c3416c54d97bec610afaca55','d2dcd8a1f9ca457e8e9448e87b27894c','李万荣',1,1,1,'2026-03-30 13:33:44','2026-03-30 13:33:44'),(13,'18019167760','15fab7286455d88396e7341a69df43c96673bd2856cf8ff11764eaf8391e829a','7f4969e1f8584e05a1e0c42d9573aab1','林一凡',1,1,1,'2026-03-30 20:45:01','2026-03-30 20:45:01'),(14,'skyhai','4a283bcdf30dd2f8a2e4b3ac55d60d3281df034c138b25c2761cf10f10a54600','1c075d26b7bb403a985f7d433d6d2ff9','常海',1,1,1,'2026-03-30 20:52:29','2026-03-30 20:52:29'),(15,'总座高见','7002ce00b39fed418c4a76af45d5e9fcaa2f14ace7c51e5a4314d9f94a32961f','fbd576d72c1f41a2841ebfeacaa3fafb','汤包',1,1,1,'2026-03-30 21:07:15','2026-03-30 21:07:15'),(16,'Yts040506','3210569d75b9ae22ec0a9e6f95546d7e3197997cd1d214217514f65188325c36','8605dc58de554bf28945c46be2f41cdf','余天晟',1,1,1,'2026-03-30 21:32:43','2026-03-30 21:32:43'),(17,'何奇丰','a3f65d937375d2e5c8d54cc0d2c6c82ac7c7cd7e446bd839b62323736edef479','8186ec9d93e94f04bb372ed662f26905','何奇丰',1,1,1,'2026-03-30 23:32:56','2026-03-30 23:32:56'),(18,'huangji','b36e22d6c8e151242c6c628fee9a3070e01680f8a685711e6fbf0429a51e322a','973b8c5d56764783967d5d6fa59cca4c','黄吉',1,1,1,'2026-04-04 17:57:17','2026-04-04 17:57:17'),(19,'shenxuetian','beea29cc5f4c33ec89bb125e0444177ec5e7942ae686eb8cd5daf2699ddfb4f9','0eb6549d599c4db9b007db8da53d7316','沈雪天',1,1,1,'2026-04-04 17:59:27','2026-04-04 17:59:27'),(20,'jing','e29ae62e82b4901adb7bcd8bed2b28144d7c1594dff2eeab488cc2ce424df392','6ad8724e547f49db964bacabffe19c02','景',1,1,1,'2026-04-04 18:00:10','2026-04-04 18:00:10'),(21,'huangjiejing','5fd0ddedc45fdfdc3517880742c641365fea5363c611f817106ec5f88dcc743f','e32b319cfb2a45d0963752aa67fb7f41','黄杰晶',1,1,1,'2026-04-04 18:04:32','2026-04-04 18:04:32'),(22,'nakata','9a5a51acef46d29a94afc20073a0a4dbf816149773a9496eda53da5c965a4fc9','26bcc132fe144e879de35732d76e0a66','王济帆',1,1,1,'2026-04-04 18:05:38','2026-04-04 18:05:38'),(23,'xjx','62b10daebcea5846490d8942f6297059cfb077cadce1445e8c948de20ff7d194','d74c95555ae34ef496eeb484a3fbf170','xjx',1,1,1,'2026-04-04 18:06:41','2026-04-04 18:06:41'),(24,'wangfanhan','d956a4dd109d54903dd761f6e1d18e8d55cc0763d1d805daf8cb4d9cb76ad5b6','8bff6df953f744848fa92c859a353e5d','王藩翰',1,1,1,'2026-04-04 18:07:54','2026-04-04 18:07:54'),(25,'moris','7921ef20a3ab3bcc5a01fd7e41546a8a4a4e992912e4890c2feabc42dd053d6b','d9fef18692e04915b495317628ee44f4','moris',1,1,1,'2026-04-04 18:08:54','2026-04-04 18:08:54'),(26,'amu','ffd87d4e8ba76fd01b568049cbb18693aa604a99618152b2849f4708a18cb278','a579bae4a4264ea583834cd32e6168a0','阿穆',1,1,1,'2026-04-04 18:09:42','2026-04-04 18:09:42'),(27,'zhaogane','5413104be4e144c4c5ddae9b6786e3051c70ef334aa12f886dd395cfc6c8488f','93193c7f7379405683b24ff5014aa357','赵赶鹅',1,1,1,'2026-04-04 18:11:05','2026-04-04 18:11:05'),(28,'aliang','3aaddef27479fb2da4146a295e691e673a4f19614cc2e780a0cad342a57d7ad4','dca9d237e8ae44c78a0b383ba9eeeb9b','阿良',1,1,1,'2026-04-04 18:12:10','2026-04-04 18:12:10');
/*!40000 ALTER TABLE `user` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user_role`
--

DROP TABLE IF EXISTS `user_role`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `user_role` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `user_id` bigint NOT NULL,
  `role_id` bigint NOT NULL,
  `created_by` bigint DEFAULT NULL,
  `updated_by` bigint DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_user_role` (`user_id`,`role_id`),
  KEY `fk_ur_role` (`role_id`),
  CONSTRAINT `fk_ur_role` FOREIGN KEY (`role_id`) REFERENCES `role` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_ur_user` FOREIGN KEY (`user_id`) REFERENCES `user` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=31 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci COMMENT='用户角色关联表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user_role`
--

LOCK TABLES `user_role` WRITE;
/*!40000 ALTER TABLE `user_role` DISABLE KEYS */;
INSERT INTO `user_role` VALUES (1,1,1,NULL,NULL,'2026-03-29 22:57:04','2026-03-29 22:57:04'),(2,1,2,NULL,NULL,'2026-03-29 22:57:04','2026-03-29 22:57:04'),(3,1,3,NULL,NULL,'2026-03-29 22:57:06','2026-03-29 22:57:06'),(8,6,2,1,1,'2026-03-30 10:17:58','2026-03-30 10:17:58'),(9,7,2,1,1,'2026-03-30 12:50:22','2026-03-30 12:50:22'),(10,8,2,7,7,'2026-03-30 12:50:44','2026-03-30 12:50:44'),(11,9,2,7,7,'2026-03-30 12:51:04','2026-03-30 12:51:04'),(12,10,2,1,1,'2026-03-30 12:58:38','2026-03-30 12:58:38'),(13,11,2,1,1,'2026-03-30 13:04:35','2026-03-30 13:04:35'),(14,12,2,1,1,'2026-03-30 13:33:44','2026-03-30 13:33:44'),(15,13,2,1,1,'2026-03-30 20:45:01','2026-03-30 20:45:01'),(16,14,2,1,1,'2026-03-30 20:52:29','2026-03-30 20:52:29'),(17,15,2,1,1,'2026-03-30 21:07:15','2026-03-30 21:07:15'),(18,16,2,1,1,'2026-03-30 21:32:43','2026-03-30 21:32:43'),(19,17,2,1,1,'2026-03-30 23:32:56','2026-03-30 23:32:56'),(20,18,2,1,1,'2026-04-04 17:57:17','2026-04-04 17:57:17'),(21,19,2,1,1,'2026-04-04 17:59:27','2026-04-04 17:59:27'),(22,20,2,1,1,'2026-04-04 18:00:10','2026-04-04 18:00:10'),(23,21,2,1,1,'2026-04-04 18:04:32','2026-04-04 18:04:32'),(24,22,2,1,1,'2026-04-04 18:05:38','2026-04-04 18:05:38'),(25,23,2,1,1,'2026-04-04 18:06:41','2026-04-04 18:06:41'),(26,24,2,1,1,'2026-04-04 18:07:54','2026-04-04 18:07:54'),(27,25,2,1,1,'2026-04-04 18:08:54','2026-04-04 18:08:54'),(28,26,2,1,1,'2026-04-04 18:09:42','2026-04-04 18:09:42'),(29,27,2,1,1,'2026-04-04 18:11:05','2026-04-04 18:11:05'),(30,28,2,1,1,'2026-04-04 18:12:10','2026-04-04 18:12:10');
/*!40000 ALTER TABLE `user_role` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping routines for database 'pitch_master'
--
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-06-19  0:23:58
